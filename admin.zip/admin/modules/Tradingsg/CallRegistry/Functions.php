<?
class CPL_Admin_Modules_Tradingsg_CallRegistry_Functions
{
    function setModuleArray($modules){

        $modObj = $modules->getModuleObj('tradingsg_callRegistry');
        $modObj['tableName'] = 'call_registry';
        $modObj['keyField']  = 'call_registry_id';
        $modules->registerModule($modObj, array(
             'hasFlagInList' => 0
            ,'title' => 'Call Registry'
            ,'actBtnsList' => array('new')
            ,'actBtnsEdit'  => array('save', 'apply', 'delete')
        ));
    }
}