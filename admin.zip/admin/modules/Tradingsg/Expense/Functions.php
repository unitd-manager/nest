<?
class CPL_Admin_Modules_Tradingsg_Expense_Functions
{
    function setModuleArray($modules){

        $modObj = $modules->getModuleObj('tradingsg_expense');
        $modules->registerModule($modObj, array(
            'tableName' => 'expense'
            ,'hasFlagInList' => 0
           ,'keyField'         => 'expense_id'
           ,'actBtnsList'   => array('new')
           ,'actBtnsEdit'   => array('apply','save', 'delete')
           ,'title'     => 'Expense'
        ));
    }
}