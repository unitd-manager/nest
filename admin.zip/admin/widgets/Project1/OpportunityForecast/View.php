<?
class CPL_Admin_Widgets_Project_OpportunityForecast_View extends CP_Admin_Widgets_Project_OpportunityForecast_View
{
    /**
     *
     */
    function getWidget() {
        $db = Zend_Registry::get('db');
        $fn = Zend_Registry::get('fn');

        $text = "
        <h2>Opportunity Forecast</h2>
        <div class='tableOuter' id='chart_opportunityForecast'>
        </div>

        <script type='text/javascript' src='https://www.google.com/jsapi'></script>
            <script type='text/javascript'>
                // Load the Visualization API and the piechart package.
                google.load('visualization', '1.0', {'packages':['corechart']});
                
                // Set a callback to run when the Google Visualization API is loaded.
                google.setOnLoadCallback(drawChart);
                
                // Callback that creates and populates a data table,
                // instantiates the pie chart, passes in the data and
                // draws it.
                function drawChart() {
                
                // Create the data table.
                var data = new google.visualization.DataTable();
                data.addColumn('string', 'Month');
                data.addColumn('number', 'Sales');
                data.addRows([
                  {$this->getRowsHTML()}
                ]);

                var chart = new google.visualization.ColumnChart(document.getElementById('chart_opportunityForecast'));
                chart.draw(data, {width: 400, height: 240, title: '',
                        hAxis: {title: 'Month', titleTextStyle: {color: 'red'}}
                });
            }
        </script>
        ";
        return $text;
    }

    /**
     *
     */
    function getRowsHTML() {
        $rows = '';

        $text = "
        ['Dec 2012', 11000],
        ['Nov 2012', 7500],
        ['Oct 2012', 9000],
        ";

        return $text;
    }

}